/*
ÖNÁLLÓ FELADAT #25: egy termék rekord módosításakor másoljuk ki egy products_log nevű táblába a
módosult termék azonosítóját, nevét és raktárkészletét!
*/
-- DROP TABLE IF EXISTS product_log
-- CREATE TABLE product_log(
--     id INT IDENTITY PRIMARY KEY,
--     prod_id INT,
--     prod_name NVARCHAR(50),
--     units_in_stock INT,
--     log_time DATETIME
-- )
IF NOT EXISTS (
    SELECT * 
    FROM sys.tables 
    WHERE name = 'product_log'
)
BEGIN
    CREATE TABLE product_log(
        id INT IDENTITY PRIMARY KEY,
        prod_id INT,
        prod_name NVARCHAR(50),
        units_in_stock INT,
        log_time DATETIME
    );
END
GO
CREATE OR ALTER TRIGGER tr_products_update ON dbo.Products AFTER UPDATE AS
BEGIN
    INSERT INTO dbo.product_log (prod_id, prod_name, units_in_stock, log_time) 
        SELECT i.ProductID, i.ProductName, i.UnitsInStock, GETDATE() FROM INSERTED AS i  
END
GO
--test
DECLARE @prod_id INT = 1
SELECT ProductName, UnitPrice FROM dbo.Products WHERE ProductID = @prod_id
UPDATE dbo.Products SET UnitPrice = UnitPrice + 1 WHERE ProductID = @prod_id
SELECT ProductName, UnitPrice FROM dbo.Products WHERE ProductID = @prod_id
SELECT * FROM dbo.product_log


