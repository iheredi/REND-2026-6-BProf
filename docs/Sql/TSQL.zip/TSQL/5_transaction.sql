--rendelés-felvétel tranzakció-kezeléssel
DECLARE @prod_name VARCHAR(20), @quantity INT, @cust_id NCHAR(5)--a telefonból (a vevő-ID szöveges)
DECLARE @status_message NVARCHAR(100), @status INT --a folyamat visszatérési értéke
DECLARE @res_no INT --találatok száma
DECLARE @prod_id INT , @order_id INT --azonositok
DECLARE @stock int --raktarkeszlet
DECLARE @cust_balance MONEY -- vevo egyenlege
DECLARE @unitprice MONEY -- termek egysegara

--parameterek
SET @prod_name = 'boston'
SET @quantity = 10
SET @cust_id ='AROUT'

BEGIN TRANSACTION
BEGIN TRY
    SELECT @res_no = COUNT(*) FROM dbo.Products WHERE ProductName LIKE '%' + @prod_name + '%'
    IF @res_no <> 1
        BEGIN
            SET @status = 1
            SET @status_message ='HIBA: a terméknév nem egyértelmű.'
        END
    ELSE
        BEGIN
            -- ha egy terméket találunk, megkeressük a kulcsot és a raktárkészletet
            SELECT @prod_id = ProductId, @stock = UnitsInStock FROM dbo.Products WHERE ProductName LIKE '%' + @prod_name + '%'
            -- van-e raktáron? a rendelt mennyiség elérheto-e?
            IF @stock < @quantity
                BEGIN
                    SET @status = 2
                    SET @status_message ='HIBA: a raktárkészlet nem fedezi a megrendelést.'
                END
            ELSE
                BEGIN
                    -- mennyibe kerül? Van elég pénze a vevönek?
                    SELECT @cust_balance = Balance FROM dbo.Customers WHERE CustomerID = @cust_id
                    --ha nem találjuk a vásárlót, akkor az egyenleg null
                    --mivel kulcsra keresünk, max. 1 találat lehet
                    SELECT @unitprice = UnitPrice FROM dbo.Products WHERE ProductID = @prod_id --nincs discount szamitas most
                    IF @cust_balance < @quantity * @unitprice OR @cust_balance IS NULL
                        BEGIN
                            SET @status = 3
                            SET @status_message ='HIBA: a vásárló nem található, vagy az egyenlege túl alacsony.'
                        END
                    ELSE
                        BEGIN
                            -- Ellenőrzések vége, elkezdjük a tranzakciót (2 lépés)
                            -- 1. vásárló egyenlegének frissítése
                            UPDATE dbo.Customers SET Balance = balance - (@quantity*@unitprice) WHERE CustomerID = @cust_id
                            -- 2. új bejegyzés az Orders, Order Details táblákba
                            INSERT INTO dbo.Orders (CustomerID, OrderDate) VALUES (@cust_id, getdate()) --orderid: identity
                            SET @order_id = @@identity --az utolsó identity insert eredménye
                            -- a kovetkezo hibas (Discount not null)
                            --INSERT dbo.[Order Details] (OrderID, ProductID, Quantity, UnitPrice) VALUES (@order_id, @prod_id, @quantity, @unitprice)
                            --ez a jo insert
                            INSERT dbo.[Order Details] (OrderID, ProductID, Quantity, UnitPrice, Discount) VALUES (@order_id, @prod_id, @quantity, @unitprice, 0)
                            set @status = 0
                            set @status_message = cast(@order_id as varchar(20)) + ' sz. rendelés sikeresen felvéve.'
                        END
                END
        END
        PRINT 'Állapot: ' + cast(@status AS VARCHAR(50))
        PRINT @status_message
        IF @status = 0 
            COMMIT TRANSACTION
        ELSE
            BEGIN
                PRINT 'Visszagörgetve'
                ROLLBACK TRANSACTION
            END
END TRY
BEGIN CATCH
    PRINT 'EGYÉB HIBA: '+ ERROR_MESSAGE() + ' (' + cast(ERROR_NUMBER() as varchar(20)) +')'
    ROLLBACK TRANSACTION
END CATCH
GO


--teszteléshez beállítjuk a paramétereket
set nocount off
update customers set balance=1000 where CustomerID='AROUT'
delete [Order Details] where OrderID in (select orderid from Orders where CustomerID='AROUT'
and EmployeeID is null)
delete Orders where CustomerID='AROUT' and EmployeeID is null
--most futtatjuk a scriptet, utána ellenőrzés:
select * from Customers where CustomerID='AROUT'
select top 3 * from Orders where CustomerID='arout' order by OrderDate desc
--a programozási hiba előtti update és insert utasítás visszagördült