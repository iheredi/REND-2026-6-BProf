DECLARE @i int, @eredm INT
SET @i = 1
--ehelyett működne ez is: declare @i int = 1, @eredm int = 0
SET @eredm = 0
WHILE @i < 50 BEGIN
    SET @eredm = @eredm + @i
    SET @i = @i + 1
END
PRINT 'Az 50-nél kisebb számok összege: ' + CAST(@eredm AS VARCHAR(30))


/* 
ÖNÁLLÓ FELADAT #4: írjunk egy scriptet, amely kiírja az 1000-nél kisebb Fibonacci-számokat! Segítség: az
első 5 szám az 1, 1, 2, 3, 5
*/
DECLARE @a BIGINT = 0, @b BIGINT = 1, @e BIGINT = 10
WHILE @e < 1000
BEGIN
    SET @e = @a + @b
    IF @e >= 1000
        BREAK
    PRINT CAST(@e AS VARCHAR(10))
    SET @a = @b
    SET @b = @e    
END


-- SQLbe ágyazva
GO
DECLARE @name NVARCHAR(30), @address NVARCHAR(max)
SET @name='King%'
SELECT @address=Country+', '+City+' '+Address
FROM dbo.Employees WHERE LastName LIKE @name
IF @address IS NOT NULL
    PRINT 'A talalt cim: ' + @address
GO
-- ha tobb rekord is van pl.
SELECT * FROM dbo.Employees WHERE LastName LIKE 'King%'
GO
DECLARE @name NVARCHAR(30), @address NVARCHAR(max), @res_no INT
SET @name = 'King%'
--SET @name='Buchanan%'
SELECT @res_no = count(*) FROM dbo.Employees WHERE LastName LIKE @name
PRINT @name + ' találatainak száma ' + CAST(@res_no AS NVARCHAR(30))
IF @res_no=0
    PRINT 'Nincs talalat'
ELSE IF @res_no>1 
    PRINT 'tobb mint 1 talalat'
ELSE 
    BEGIN
        SELECT @address=Country+', '+City+' '+Address
        FROM dbo.Employees WHERE LastName LIKE @name
        PRINT 'A talalt cim: ' + @address
    END
GO
-- a fenti két select össze is vontható:
DECLARE @name NVARCHAR(30), @address NVARCHAR(max), @res_no INT
SET @name = 'King%'
SET @name='Buchanan%'
SELECT @res_no = count(*), @address=MAX(Country+', '+City+' '+Address) FROM dbo.Employees WHERE LastName LIKE @name
--MAX() - hogy biztos csak egy talalat legyen, csak azt akarjuk ugyanis kiirni
IF @res_no=0
    PRINT 'Nincs talalat'
ELSE IF @res_no>1 
    PRINT 'tobb mint 1 talalat'
ELSE 
    PRINT @address
GO




/*
ÖNÁLLÓ FELADAT #5: írjunk egy scriptet, amely a kapott nevű termék termék-kategóriáját visszaírja
*/
GO
DECLARE @prodName NVARCHAR(30) = 'Tofu%'
SELECT ProductID, ProductName, CategoryId FROM dbo.Products WHERE ProductName LIKE @prodName -- testing
DECLARE @catID INT
SELECT @catID = CategoryID FROM dbo.Products WHERE ProductName LIKE @prodName
SELECT CategoryName FROM dbo.Categories WHERE CategoryID = @catid
GO

-- talalati szam ellenorzessel
GO
DECLARE @prodName NVARCHAR(30)
SET @prodName = 'Tofu%'
SET @prodName = '%od%'
--SELECT ProductID, ProductName, CategoryId FROM dbo.Products WHERE ProductName LIKE @prodName -- testing
DECLARE @catID INT, @res_count INT
SELECT @res_count = count(*) FROM dbo.Products WHERE ProductName LIKE @prodName
PRINT @prodName + ' talalatok szama: ' + CAST(@res_count AS NVARCHAR(20))
IF @res_count < 1
    PRINT 'nincs talalat'
ELSE IF @res_count > 1
    PRINT 'tobb talalat'
ELSE
    BEGIN
        SELECT @catID = CategoryID FROM dbo.Products WHERE ProductName LIKE @prodName
        SELECT CategoryName FROM dbo.Categories WHERE CategoryID = @catid
    END
GO

