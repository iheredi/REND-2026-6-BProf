/*
ÖNÁLLÓ FELADAT #24: írjunk függvényt, amely egy táblában visszaadja a paraméterként kapott
azonosítójú alkalmazotthoz tartozó területek nevét és régióját (RegionDescription és TerritoryDescription
mezők)!
*/
GO
CREATE OR ALTER FUNCTION usf_get_region_territory(@emp_id INT) RETURNS TABLE AS
RETURN (
    SELECT RegionDescription, TerritoryDescription FROM dbo.EmployeeTerritories AS e
    INNER JOIN dbo.Territories AS t ON e.TerritoryID = t.TerritoryID
    INNER JOIN dbo.Region AS r ON t.RegionID = r.RegionID
    WHERE EmployeeID = @emp_id
)
GO

SELECT * FROM usf_get_region_territory(1)

SELECT e.EmployeeID, e.LastName, t.RegionDescription, t.TerritoryDescription FROM dbo.Employees e
    OUTER APPLY usf_get_region_territory(e.EmployeeID) t;
