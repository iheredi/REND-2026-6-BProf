drop table dbo.csapat
CREATE TABLE [dbo].[csapat] (
[csapat_id] [int] NOT NULL primary key,
[csapat_nev] [nvarchar] (50) NOT NULL
)
drop table gyumolcs
CREATE TABLE [dbo].[gyumolcs] (
[gyumolcs_id] [int] NOT NULL primary key,
[gyumolcs_nev] [nvarchar] (50) NOT NULL
)
drop table nap
CREATE TABLE [dbo].[nap] (
[nap_id] [int] NOT NULL primary key,
[nap_nev] [nvarchar] (50) NOT NULL
)
go
drop table eredm
CREATE TABLE [dbo].[eredm] (
eredm_id int identity (1,1) primary key,
[csapat_id] [int] NOT NULL references csapat (csapat_id),
[nap_id] [int] NOT NULL references nap (nap_id),
gyumolcs_id int not null references gyumolcs (gyumolcs_id),
[leadott_lada] [int] NOT NULL
)
insert csapat (csapat_id, csapat_nev) values (1, 'Szorgos'),(2, 'Lusta')
insert gyumolcs (gyumolcs_id, gyumolcs_nev) values (1, 'alma'),(2, 'szilva')
insert nap (nap_id, nap_nev) values (1, 'hétfő'),(2, 'kedd'),(3, 'szerda')
insert eredm (csapat_id, nap_id, gyumolcs_id, leadott_lada) values
(1,1,1,50), (1,2,1,60), (1,3,1,70), (1,1,2,100), (1,2,2,120), (1,3,2,140),
(2,1,1,5), (2,2,1,6), (2,3,1,7), (2,1,2,10), (2,2,2,12), (2,3,2,14)
select * from eredm



--NÉHÁNY PÉLDA CSOPORTOSÍTÓ LEKÉRDEZÉSEKRE
--kérdés pl. a csapatok teljesítménye naponta
select cs.csapat_nev, n.nap_nev, sum(leadott_lada) as teljesítmény
from eredm e inner join csapat cs on cs.csapat_id=e.csapat_id
inner join nap n on n.nap_id=e.nap_id
inner join gyumolcs gy on gy.gyumolcs_id=e.gyumolcs_id --elhagyható
group by cs.csapat_id, cs.csapat_nev, n.nap_id, n.nap_nev
order by cs.csapat_nev, n.nap_nev

--csapatok teljesítménye gyümölcsönként
select cs.csapat_nev, gy.gyumolcs_nev, sum(leadott_lada) as teljesítmény
from eredm e inner join csapat cs on cs.csapat_id=e.csapat_id
inner join nap n on n.nap_id=e.nap_id --elhagyható
inner join gyumolcs gy on gy.gyumolcs_id=e.gyumolcs_id
group by cs.csapat_id, cs.csapat_nev, gy.gyumolcs_id, gy.gyumolcs_nev
order by cs.csapat_nev, gy.gyumolcs_nev

--ládaszám gyümölcsönként
select gy.gyumolcs_nev, sum(leadott_lada) as teljesítmény
from eredm e
inner join csapat cs on cs.csapat_id=e.csapat_id --elhagyható
inner join nap n on n.nap_id=e.nap_id --elhagyható
inner join gyumolcs gy on gy.gyumolcs_id=e.gyumolcs_id
group by gy.gyumolcs_id, gy.gyumolcs_nev
order by gy.gyumolcs_nev

--Az egyszerűség kedvéért legyen egyetlen szöveges kiinduló táblánk:
drop table IF EXISTS eredm_pivot
select cs.csapat_nev, n.nap_nev, gy.gyumolcs_nev, e.leadott_lada
into eredm_pivot
from eredm e
inner join csapat cs on cs.csapat_id=e.csapat_id
inner join nap n on n.nap_id=e.nap_id
inner join gyumolcs gy on gy.gyumolcs_id=e.gyumolcs_id
go


-- PIVOT FELADATOK
SELECT * FROM eredm_pivot
-- a gyümölcsök az oszlopokban jelenjenek meg
SELECT csapat_nev, nap_nev, pt.alma, pt.szilva
FROM eredm_pivot
PIVOT(SUM(leadott_lada)
    FOR gyumolcs_nev IN (alma, szilva)
    ) AS pt
ORDER BY csapat_nev, nap_nev
/* ÖNÁLLÓ FELADAT:
Legyenek sorokban a napok és gyümölcsök, oszlopokban a csapatok */
select * from eredm_pivot where csapat_nev='lusta'
SELECT nap_nev, gyumolcs_nev, pt.lusta, pt.szorgos
FROM eredm_pivot
PIVOT(SUM(leadott_lada)
    FOR csapat_nev IN (Lusta, Szorgos)) AS pt
ORDER BY nap_nev, gyumolcs_nev


--most összesítünk: a napok nem érdekesek
--csapatok teljesítménye gyümölcsönként: sorokban a csapatok, oszlopokban a gyümölcsök
select pt.csapat_nev, pt.alma, pt.szilva
from (select csapat_nev, gyumolcs_nev, sum(leadott_lada) as leadott_lada
from eredm_pivot group by csapat_nev, gyumolcs_nev) as forras --az alias szintaktikai okból kell
pivot (sum(leadott_lada) for gyumolcs_nev in ([alma], [szilva])) as pt

-- csapatok gyumolcsonkent group by leadott_lada (ezt agyazzuk be lekerdezesbe)
SELECT csapat_nev, gyumolcs_nev, SUM(leadott_lada) AS leadott_lada
FROM eredm_pivot
GROUP BY csapat_nev, gyumolcs_nev

SELECT pt.csapat_nev, pt.alma, pt.szilva
FROM (
    SELECT csapat_nev, gyumolcs_nev, SUM(leadott_lada) AS leadott_lada
    FROM eredm_pivot
    GROUP BY csapat_nev, gyumolcs_nev
) AS forras -- szintaktikai okbol kell
PIVOT (SUM(leadott_lada)
    FOR gyumolcs_nev IN (alma,szilva)) AS pt

--sorokban a gyümölcsök, oszlopokban a csapatok
SELECT gyumolcs_nev, pt.Lusta, pt.Szorgos
FROM (
    SELECT csapat_nev, gyumolcs_nev, SUM(leadott_lada) AS leadott_lada
    FROM eredm_pivot
    GROUP BY csapat_nev, gyumolcs_nev
) AS forras -- szintaktikai okbol kell
PIVOT (SUM(leadott_lada)
    FOR csapat_nev IN (Lusta,Szorgos)) AS pt

--mi lenne, ha kihagynánk a keddet? -> a belső lekérdezés változik
-- forras valtozik
SELECT csapat_nev, gyumolcs_nev, SUM(leadott_lada) AS leadott_lada
FROM eredm_pivot
WHERE nap_nev <>'kedd'
GROUP BY csapat_nev, gyumolcs_nev

SELECT gyumolcs_nev, pt.Lusta, pt.Szorgos
FROM (
    SELECT csapat_nev, gyumolcs_nev, SUM(leadott_lada) AS leadott_lada
    FROM eredm_pivot
    WHERE nap_nev <>'kedd'
    GROUP BY csapat_nev, gyumolcs_nev
) AS forras -- szintaktikai okbol kell
PIVOT (SUM(leadott_lada)
    FOR csapat_nev IN (Lusta,Szorgos)) AS pt

/*
ÖNÁLLÓ FELADAT:
Legyenek sorokban a napok, oszlopokban a csapatok
...és hagyjuk ki a szerdát
*/
SELECT nap_nev, pt.Lusta, pt.Szorgos
FROM (
    SELECT csapat_nev, gyumolcs_nev, nap_nev, SUM(leadott_lada) AS leadott_lada
    FROM eredm_pivot
    WHERE nap_nev<>'szerda'
    GROUP BY csapat_nev, nap_nev, gyumolcs_nev
) AS forras
PIVOT(SUM(leadott_lada) FOR csapat_nev IN (Lusta, Szorgos)) AS pt
-- tobb sorszintu bontas
SELECT gyumolcs_nev, nap_nev, pt.Lusta, pt.Szorgos
FROM (
    SELECT csapat_nev, gyumolcs_nev, nap_nev, SUM(leadott_lada) AS leadott_lada
    FROM eredm_pivot
    WHERE nap_nev<>'szerda'
    GROUP BY csapat_nev, nap_nev, gyumolcs_nev
) AS forras
PIVOT(SUM(leadott_lada) FOR csapat_nev IN (Lusta, Szorgos)) AS pt


--a sorokban lehet több szintű bontás is: sorokban a csapatok és napok, oszlopokban a gyümölcsök
select * from eredm_pivot
select csapat_nev, nap_nev, pt.alma, pt.szilva
from (select csapat_nev, nap_nev, gyumolcs_nev, sum(leadott_lada) as leadott_lada
from eredm_pivot group by csapat_nev, nap_nev, gyumolcs_nev) as forras --ehhez már nem is kellett volna belső lekérdezés
pivot (sum(leadott_lada) for gyumolcs_nev in ([alma], [szilva])) as pt
order by csapat_nev, nap_nev


-------------- UNPIVOT
--induljunk ki egy pivotált táblából:
select csapat_nev, pt.alma, pt.szilva
into #temp
from (select csapat_nev, gyumolcs_nev, sum(leadott_lada) as leadott_lada
from eredm_pivot group by csapat_nev, gyumolcs_nev) as forras
pivot (sum(leadott_lada) for gyumolcs_nev in ([alma], [szilva])) as pt
select * from #temp

--és tegyük vissza gyümölcsöket a sorokba:
select csapat_nev, gyumolcs_nev, leadott_lada
from #temp
unpivot (leadott_lada for gyumolcs_nev in (alma, szilva)) as upt
--persze a csoportosítást már nem tudjuk visszacsinálni, ott információ veszett el

--ha nem volt csoportosítás (GROUP BY), akkor a tábla teljesen visszaalakítható:
drop table #temp
GO
select csapat_nev, nap_nev, pt.alma, pt.szilva
into #temp
from eredm_pivot
pivot (sum(leadott_lada) for gyumolcs_nev in ([alma], [szilva])) as pt
order by csapat_nev, nap_nev
select csapat_nev, nap_nev, gyumolcs_nev, leadott_lada
from #temp
unpivot (leadott_lada for gyumolcs_nev in (alma, szilva)) as upt
order by csapat_nev, nap_nev, gyumolcs_nev


--a dolgozós rekordorientált modell visszaírása mezőorientáltra PIVOT segítségével
--Mi a mezőnév-készlet?
select distinct a.attrib_name from employee_record e inner join attributes a on e.attrib_id=a.attrib_id
--ezzel a megoldás:
select emp_id, pt.[City], pt.[Last name], pt.[Title]
from (
select e.emp_id, a.attrib_name, e.attrib_value
from employee_record e inner join attributes a on e.attrib_id=a.attrib_id) as forras
pivot (max(attrib_value) for attrib_name in ([City],[Last name],[Title])) as pt
--max helyett lehetne min is