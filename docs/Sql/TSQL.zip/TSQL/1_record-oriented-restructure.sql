-----------------------------------------------
-- Employee tabla atalakitas rekord-orientaltra
-----------------------------------------------
SELECT * FROM dbo.Employees

--DROP TABLE employee_filed
SELECT EmployeeID, LastName, Title, City INTO employee_field FROM dbo.Employees
SELECT * FROM dbo.employee_field
CREATE TABLE attributes (
    attrib_id int PRIMARY KEY,
    attrib_name NVARCHAR(100),
    attrib_type NVARCHAR(100)
)
GO -- itt megállunk és lefuttatjuk
INSERT dbo.attributes (attrib_id, attrib_name, attrib_type) values (1, 'Last name', 'text'), (2, 'Title', 'text'), (3, 'City', 'text')

--DROP TABLE employee_record
CREATE TABLE employee_record (
    emp_id INT NOT NULL,
    attrib_id INT NOT NULL REFERENCES attributes (attrib_id),
    attrib_value NVARCHAR(30)
    PRIMARY KEY (emp_id, attrib_id)
)


--a feladat az employee_field tartalmának reprodukálása az employee_record táblában
--egy rekordból több rekord lesz:
INSERT INTO dbo.employee_record (emp_id, attrib_id, attrib_value)
    SELECT EmployeeID, 1, LastName FROM dbo.employee_field where LastName IS NOT NULL
    UNION
    SELECT EmployeeID, 2, Title FROM dbo.employee_field where Title IS NOT NULL
    UNION
    SELECT EmployeeID, 3, City FROM dbo.employee_field where City IS NOT NULL
GO

--ellenőrzés: Lamer NULL rekordjai ugye nincsenek benne
SELECT * FROM employee_record


--a kliens GUI számára fontosak a mezőnevek, típusok is:
SELECT e.emp_id, a.attrib_name, a.attrib_type, e.attrib_value FROM dbo.employee_record e INNER JOIN dbo.attributes a ON e.attrib_id=a.attrib_id


--most alakítsuk vissza: több rekordból lesz egy rekord
SELECT emp_id AS employeeid,
    MIN(CASE  --MIN helyén lehetne MAX is, mert csak egy rekordot dolgoz fel
            WHEN attrib_id=1 THEN attrib_value
            ELSE NULL
    END) AS LastName,
    MIN(CASE 
            WHEN attrib_id=2 THEN attrib_value
            ELSE NULL
    END) AS Title,
    MIN(CASE 
            WHEN attrib_id=3 THEN attrib_value
    END) AS City
FROM employee_record GROUP BY emp_id
--megkaptuk az employee_field tartalmát

