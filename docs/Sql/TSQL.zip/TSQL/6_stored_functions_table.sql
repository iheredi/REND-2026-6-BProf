/*
PÉLDA: a függvény visszaadja a paraméterül kapott termékkategória termékeinek a nevét és az illető
termék rendeléseinek a számát.
*/
create function kateg_termekei (@kat_id int) returns table as
return (
select p.ProductName as termeknev, COUNT(*) as rendelesek_szama
from Products p inner join [Order Details] od on p.ProductID=od.ProductID
where p.CategoryID=@kat_id
group by p.ProductID, p.ProductName)
go
select * from dbo.kateg_termekei(1) where rendelesek_szama>30