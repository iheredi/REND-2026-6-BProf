/*
ÖNÁLLÓ FELADAT #21: írjunk függvényt, amely a paraméterül kapott alkalmazott ID (EmployeeID) alapján
visszaadja az illető eddigi rendeléseinek a számát! Teszteljük a függvényt SELECT lekérdezéssel!
*/
GO
CREATE OR ALTER FUNCTION usf_get_order_count_by_id (@emp_id INT) RETURNS INT AS
BEGIN
    DECLARE @order_count INT
    SELECT @order_count = COUNT(*) FROM dbo.Orders WHERE EmployeeID = @emp_id
    RETURN @order_count
END
GO
--test
SELECT EmployeeID,LastName,dbo.usf_get_order_count_by_id(EmployeeID) AS OrderCount FROM dbo.Employees