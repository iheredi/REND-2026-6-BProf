GO
DROP FUNCTION fn_ev_honap
GO
CREATE FUNCTION fn_ev_honap (@datum DATETIME) RETURNS VARCHAR(50) AS
BEGIN
    DECLARE @eredm VARCHAR(50)
    SET @eredm = CASE
        WHEN MONTH(@datum) < 10 THEN CAST(YEAR(@datum) AS VARCHAR(4)) + '_0' + CAST(MONTH(@datum) AS VARCHAR(2))
        WHEN MONTH(@datum) >= 10 THEN CAST(YEAR(@datum) AS VARCHAR(4)) + '_' + CAST(MONTH(@datum) AS VARCHAR(2))
        ELSE 'N.A'
    END
    RETURN @eredm
END
GO

--SELECT lekérdezésben felhasználható:
select e.employeeid, lastname, dbo.fn_ev_honap(orderdate) as honap,
count(orderid) as rend_szam
from employees e left outer join orders o on e.employeeid=o.employeeid
group by e.employeeid, lastname, dbo.fn_ev_honap(orderdate)
order by lastname, honap