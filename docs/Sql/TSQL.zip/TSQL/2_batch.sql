--drop table pelda
drop table if exists pelda
create table pelda (szam int)
insert pelda values (44)
go
--1. kísérlet
update pelda set szam=21
go
selec * from pelda --szintaktikai hiba
go
select * from pelda --eredmeny 21, mert az első batch sikerult
go
--2. kísérlet: ugyanez egy kötegben
update pelda set szam=22
selec * from pelda --szintaktikai hiba
update pelda set szam=23
go
select * from pelda --eredmény: 21
--mert szintaktikai hiba esetén az egész batchból semmi sem hajtódik végre
--3. kísérlet
--ha az objektumnév hibás (nem szintaktikai hiba), akkor a hiba előtti rész végrehajtódik
go
update pelda set szam=22
select * from plda --Invalid object name
update pelda set szam=23 --ez már nem hajtódik végre
go
select * from pelda --eredmény: 22
go
--4. kísérlet: speciális hibák (nullával osztás, külső kulcs kényszer)
update pelda set szam=23
select 1/0 --division by zero
update pelda set szam=24 --végrehajtódik
go
select * from pelda --eredmény: 24
go
update pelda set szam=25
delete employees --The DELETE statement conflicted with the REFERENCE constraint
update pelda set szam=26 --végrehajtódik
go
select * from pelda --eredmény: 26



