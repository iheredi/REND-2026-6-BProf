
/*
ÖNÁLLÓ FELADAT #10 (szorgalmi): Raktárkészlet-karbantartó script. A scriptet a raktáros használja arra,
hogy egy létező termék raktárkészletét növelje, vagy egy új cikket vegyen fel a raktárba. Bemenő
paraméterek (konkrét példákkal):
set @termeknev = 'Raclette'
set @mennyiseg = 12
set @szallito = 'Formago Company'
Ekkor a script '%raclette%'-re illő terméknevet keres a Products táblában. Ha több mint 1 találat van,
hibaüzenettel kilép. Ha pont 1 találat van, akkor annak a raktárkészletét (UnitsInStock) növeli 12-vel. Ha
nincs találat, akkor felvesz egy új Raclette nevű terméket, melynek a szállítóját (supplier) a 3. paraméter
alapján próbálja beállítani, a fentihez hasonló logikával (több találat: hiba, 1 találat: megvan, 0 találat: új
supplier rekord felvétele). Javasolt lépések:
1. lépés: olyan lekérdezés, amely visszaadja a mintára illeszkedő rekordok számát
2. lépés: beszúró INSERT illetve módosító UPDATE utasítás összerakása
3. lépés: a lekérdezések beágyazása egy IF feltételt használó script-be
4. lépés: a script tesztelése
*/
GO
DECLARE @termeknev AS NVARCHAR(40), @mennyiseg AS INT, @szallito AS NVARCHAR(40)
DECLARE @res_count AS INT
DECLARE @new_product_id AS INT, @supplier_id AS INT

--SET @termeknev = 'Raclette'
SET @termeknev = 'Képviselőfánk'
--SET @termeknev = 'e'
SET @mennyiseg = 12
SET @szallito = 'Formago Company'

SELECT @res_count = COUNT(*) FROM dbo.Products WHERE ProductName LIKE '%' + @termeknev + '%'
IF @res_count = 1
    -- ha 1 talalat, 12-vel noveljuk a raktarkeszletet
    BEGIN
        PRINT 'Talalatok szama: ' + CAST(@res_count AS NVARCHAR(4))
        --tesztelés előtte
        SELECT ProductName, UnitsInStock FROM Products WHERE ProductName LIKE '%' + @termeknev + '%'
        -- raktarkeszlet modositas
        UPDATE dbo.Products SET UnitsInStock += 12 WHERE ProductName LIKE '%' + @termeknev + '%'
        --teszteles utana
        SELECT ProductName, UnitsInStock FROM Products WHERE ProductName LIKE '%' + @termeknev + '%'        
    END
ELSE IF @res_count = 0
    -- Nincs ilyen termek, újat kell felvinni
    BEGIN
        -- szallito beallitasa
        SELECT @res_count = COUNT(*) FROM dbo.Suppliers WHERE CompanyName LIKE '%'+@szallito+'%'
        IF @res_count = 0
            --felveszunk egy uj szallitot
            BEGIN
                INSERT dbo.Suppliers (CompanyName) VALUES(@szallito)
                SET @supplier_id = @@IDENTITY
            END
        IF @res_count = 1
            --lekerjuk a szallito id-et
            SELECT @supplier_id = SupplierID FROM dbo.Suppliers WHERE CompanyName LIKE '%'+@szallito+'%'
        IF @res_count > 1
            --hibakezeles
            BEGIN
                PRINT 'HIBA: Több mint 1 talalat ('+CAST(@res_count AS NVARCHAR(4))+')!'
            END
        -- felvisszuk a teremeket
        INSERT Products (ProductName,SupplierID, Discontinued) VALUES (@termeknev, @supplier_id, 0)
        SET @new_product_id = @@IDENTITY --utolso identity insert eredmenye        
        --ellenorzes
        SELECT ProductName, UnitsInStock, CompanyName 
            FROM dbo.Products LEFT JOIN dbo.Suppliers ON Suppliers.SupplierID = Products.SupplierID
            WHERE ProductName LIKE '%' + @termeknev + '%'   
    END
ELSE IF @res_count > 1
    PRINT 'HIBA: Több mint 1 talalat ('+CAST(@res_count AS NVARCHAR(4))+')!'
ELSE
    PRINT 'HIBA: ismeretlen hiba'
GO
