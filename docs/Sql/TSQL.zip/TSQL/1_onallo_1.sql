-- Önálló #1
-- Készítsük el és töltsük fel a Products tábla rekord-orientált változatát, ha a tárolt
-- attribútumok a Productname, a Unitprice, és a Discontinued!

SELECT * FROM dbo.Products
-- megfelelo mezok tablaja letrehozas
DROP TABLE IF EXISTS products_fields
SELECT ProductId, ProductName, UnitPrice, Discontinued INTO products_fields FROM dbo.Products
-- ellenorzes
SELECT * FROM dbo.products_fields
-- attrib tabla letrehozasa
CREATE TABLE product_attributes (
    attrib_id INT PRIMARY KEY,
    attrib_name NVARCHAR(100),
    attrib_type NVARCHAR(100)
)
GO
-- miutan letrejott az attrib tabla, feltoltjuk
INSERT INTO product_attributes (attrib_id, attrib_name, attrib_type)
VALUES (1, 'ProductName', 'text'), (2,'UnitPrice','money'), (3,'Discontinued','bit') -- UNION nem fog mukodni kulonbozo tipusokkal, vagy castolni kell kozosre
-- ellenorzes
SELECT * FROM product_attributes

-- rekord orientalt tabla letrehozasa, ha letezik, toroljuk
DROP TABLE IF EXISTS products_records
CREATE TABLE products_records (
    prod_id INT NOT NULL,
    attrib_id INT NOT NULL,
    attrib_type NVARCHAR (100)
    PRIMARY KEY (prod_id, attrib_id)
)
GO
-- rekord orientalt tabla feltoltese
-- INSERT INTO products_records (prod_id, attrib_id, attrib_type)
--   SELECT ProductId, 1, CAST(ProductName AS NVARCHAR(100)) FROM products_fields WHERE ProductName IS NOT NULL
-- INSERT INTO products_records (prod_id, attrib_id, attrib_type)
--   SELECT ProductId, 2, CAST(UnitPrice AS NVARCHAR(100)) FROM products_fields WHERE UnitPrice IS NOT NULL
-- INSERT INTO products_records (prod_id, attrib_id, attrib_type)
--   SELECT ProductId, 3, CAST(Discontinued AS INT) FROM products_fields WHERE Discontinued IS NOT NULL
-- UNION megoldas
INSERT products_records (prod_id, attrib_id, attrib_type)
    SELECT ProductId, 1, CAST(ProductName AS NVARCHAR(100)) FROM products_fields WHERE ProductName IS NOT NULL
    UNION
    SELECT ProductId, 2, CAST(UnitPrice AS NVARCHAR(100)) FROM products_fields WHERE UnitPrice IS NOT NULL
    UNION
    SELECT ProductId, 3, CAST(Discontinued AS NVARCHAR(100)) FROM products_fields WHERE Discontinued IS NOT NULL
GO

-- ellenorzes
SELECT p.prod_id, a.attrib_name, p.attrib_type FROM products_records AS p LEFT JOIN product_attributes AS a on p.attrib_id = a.attrib_id
