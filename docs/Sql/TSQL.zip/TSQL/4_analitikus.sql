go
drop table #tmp --az átláthatóság érdekében használjunk egy ideiglenes táblát
go
select orderdate, cast(sum((1-discount)*unitprice*quantity) as money) as value
into #tmp from orders o inner join [order details] d on o.orderid=d.orderid
where EmployeeID = 2
group by o.orderid, o.orderdate --96
order by OrderDate
go
select * from #tmp order by OrderDate


select orderdate, max(value) over
(order by orderdate rows between 1 preceding and current row) as maxi-- maxi: arendelés és az előző rendelés közül a nagyobbik érték
from #tmp