/*
ÖNÁLLÓ FELADAT #18: valósítsuk meg az alábbi egyszerű tranzakciót, melynek paraméterei a termék neve
és a termék kategóriájának ID-je (a Products tábla ProductName és CategoryID mezői). A lépések:
• új termék beszúrása a kapott névvel a Products táblába
• annak ellenőrzése, hogy a kapott kategóriában nincs-e már 10-nél több termék
• ha van, visszagörgetjük a tranzakciót (ROLLBACK)
• ha nincs, az újonnan felvett termék raktárkészletét beállítjuk 100-ra
• A tranzakció befejezése (COMMIT)

Ellenőrizzük a visszagörgetés megtörténtét!
*/
--SELECT ProductName, CategoryID FROM dbo.Products
GO
DECLARE @res_count INT
DECLARE @new_product_name NVARCHAR(50), @new_category_id INT, @new_product_id INT
SET @new_product_name = N'Kőrözöttes kenyér'
SET @new_category_id = 2
BEGIN TRANSACTION
    INSERT INTO dbo.Products(ProductName, CategoryID) VALUES (@new_product_name, @new_category_id)
    SET @new_product_id = @@IDENTITY
    SELECT @res_count = COUNT(*) FROM dbo.Products WHERE CategoryID = @new_category_id
    IF @res_count > 10
        BEGIN
            PRINT 'Több, mint 10 termék van az ID: '+ CAST(@new_category_id AS NVARCHAR(3)) +' kategóriában, ROLLBACK!'
            ROLLBACK TRANSACTION
        END
    ELSE
        BEGIN
            UPDATE dbo.Products SET UnitsInStock = 100 WHERE ProductID = @new_product_id
            PRINT @new_product_name + ' rögzítve, készlet 100-ra állítva'
            COMMIT TRANSACTION
        END
--visszagörgetés ellenőrzése
SELECT ProductName, CategoryID, UnitsInStock FROM dbo.Products WHERE CategoryID = @new_category_id
