/*PÉLDA: minden új rendelés beszúrásakor emeljük meg az alkalmazott fizetését 2%-kal*/

create trigger tr_uj_rend on orders after insert as
begin
declare @i int
select @i=COUNT(*) from inserted
print 'Beszúrt rekordok száma: '+cast(@i as varchar(50))
update Employees set Salary=Salary*1.02
where EmployeeID in (select EmployeeID from inserted)
end
--több rekordra is működik
go

--teszt
select salary from Employees where EmployeeID=3 --100
insert Orders (EmployeeID) values (3)
select salary from Employees where EmployeeID=3 --102