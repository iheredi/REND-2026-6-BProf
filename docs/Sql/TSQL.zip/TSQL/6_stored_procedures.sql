/*
PÉLDA: emeljük meg a paraméterként kapott nevű dolgozó fizetését 10%-kal (most tranzakció-kezelés
nélkül)
*/
DROP PROCEDURE IF EXISTS sp_inc_salary;
GO
CREATE PROCEDURE sp_inc_salary @name NVARCHAR(20) AS
BEGIN TRY    
    DECLARE @res_count INT
    SELECT @res_count = COUNT(*) FROM dbo.Employees WHERE LastName = @name
    IF @res_count = 0
        PRINT 'Nincs talalat'
    ELSE IF @res_count > 1
        PRINT 'Tobb mint 1 talalat'
    ELSE
        BEGIN
            DECLARE @emp_id INT
            SELECT @emp_id = EmployeeID FROM dbo.Employees WHERE LastName = @name
            PRINT 'Dolgozó ID: ' + CAST(@emp_id AS NVARCHAR(4))
            UPDATE dbo.Employees SET Salary = Salary*1.1 WHERE EmployeeID=@emp_id
            PRINT 'Egyenleg novelve'
        END
END TRY    
BEGIN CATCH
    PRINT 'EGYEB HIBA: ' + ERROR_MESSAGE() +' (' + cast(ERROR_NUMBER() AS VARCHAR(20)) + ')'
END CATCH
GO
--teszt
GO
DECLARE @e_name NVARCHAR(20) = 'Fuller'
SELECT EmployeeID,LastName,Salary FROM dbo.Employees WHERE LastName = @e_name
EXECUTE sp_inc_salary @e_name
SELECT EmployeeID,LastName,Salary FROM dbo.Employees WHERE LastName = @e_name
GO

-- lekerdezni
EXEC sp_helptext 'sp_inc_salary';



/*
ÖNÁLLÓ FELADAT #20: írjunk egy tárolt eljárást, amely a kapott azonosítójú termék termék-kategóriáját
visszaírja
*/
GO
CREATE OR ALTER PROCEDURE usp_get_categoryNameByProductName @prod_name VARCHAR(50) AS
BEGIN TRY
    DECLARE @category_id INT, @category_count INT
    SELECT @category_count = COUNT(CategoryID) FROM dbo.Products WHERE ProductName LIKE '%' + @prod_name + '%'
    IF @category_count <> 1
        PRINT 'HIBA: Nem egyértelmű termék'
    ELSE
        BEGIN
            SELECT @category_id = CategoryID FROM dbo.Products WHERE ProductName LIKE '%' + @prod_name + '%'
            SELECT CategoryName FROM dbo.Categories WHERE CategoryID = @category_id            
        END
END TRY
BEGIN CATCH
    PRINT 'EGYEB HIBA: ' + ERROR_MESSAGE() +' (' + cast(ERROR_NUMBER() AS VARCHAR(20)) + ')'
END CATCH
GO
-- test
EXECUTE usp_get_categoryNameByProductName 'fánk'
GO
