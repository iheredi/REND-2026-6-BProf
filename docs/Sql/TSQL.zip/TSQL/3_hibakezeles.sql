go
select 1/0
if @@ERROR=8134 print '0-val osztottunk'
go


create table #log(time_stamp datetime, err_num int)
go
begin try
    update Products set UnitsInStock=-13 where ProductID=3 --check constraint sértés
    select 1/0
end try
begin catch
    select
    ERROR_NUMBER() AS ErrorNumber,
    ERROR_SEVERITY() AS ErrorSeverity,
    ERROR_STATE() AS ErrorState,
    ERROR_PROCEDURE() AS ErrorProcedure,
    ERROR_LINE() AS ErrorLine,
    ERROR_MESSAGE() AS ErrorMessage
    insert #log (time_stamp, err_num) values (getdate(), ERROR_NUMBER())
end catch
select * from #log
go


/*
ÖNÁLLÓ FELADAT #9: Az alábbi kis script a Products.UnitsInStock (raktárkészlet) értékét aktualizálja, mikor
egy rendelést kiszolgálnak a raktárból.
*/
select * from [Order Details] where OrderID=10248 --11: 42, 42: 40, 72:40
select ProductID, UnitsInStock from Products where ProductID in (11, 42, 72) --82, 20, 20
--az utolsó 2 tétel miatt az alábbi update hibára fut (nem lehet negatív raktárkészlet)
go
declare @order_id int = 10248
BEGIN TRY
    update Products set UnitsInStock=UnitsInStock-od.Quantity
    from [Order Details] od inner join Products p on p.ProductID=od.ProductID
    where od.OrderID=@order_id
END TRY
BEGIN CATCH
    IF @@ERROR=547
        PRINT 'RAKTARKESZLET-HIBA: '+CAST(@order_id AS VARCHAR(9))+' szamu rendelesen nem teljesitheto'
    ELSE
        PRINT 'EGYEB HIBA: Divide by zero encountered'
END CATCH
print cast(@order_id as varchar(20))+' számú rendelés a raktárba átvezetve.'--hibás üzenet




