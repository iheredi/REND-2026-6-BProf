GO
DECLARE @emp_id INT, @emp_name NVARCHAR(50), @i INT, @address NVARCHAR(60)
DECLARE cursor_emp CURSOR FAST_FORWARD FOR
    SELECT employeeid, lastname, address
FROM dbo.Employees
ORDER BY lastname
SET @i = 1
OPEN cursor_emp
FETCH NEXT FROM cursor_emp INTO @emp_id, @emp_name, @address
WHILE @@FETCH_STATUS = 0
BEGIN
    PRINT CAST(@i AS VARCHAR(5)) + '. ügynök:'
    PRINT CONCAT('ID: ', @emp_id, ', Név: ', @emp_name, ', cím: ', @address)
    SET @i=@i+1
    FETCH NEXT FROM cursor_emp INTO @emp_id, @emp_name, @address
END
CLOSE cursor_emp
DEALLOCATE cursor_emp
GO

--ez egyenértékű egy ilyen SELECT utasítással:
select 'ID: ' + cast(employeeid as varchar(5)) + isnull(', Név: ' + lastname, '') + isnull( ',
cím: ' + address, '')
from employees
order by lastname
--illetve ha az ügynök sorszámát is szeretnénk:
select cast(row_number() over(order by lastname) as varchar(50))+
'. ügynök: ID: ' + cast(employeeid as varchar(5)) + isnull(', Név: ' + lastname, '') + isnull(
', cím: ' + address, '')
from employees
--tehát ehhez még nem kellett volna kurzor…


/*
ÖNÁLLÓ FELADAT #11: készítsünk olyan scriptet, amely az amerikai vásárlók (customers tábla, country
mező) rekordjain iterál és kiírja minden vásárló nevét, és azt, hogy eddig hány rendelése volt
*/
SELECT CustomerID, CompanyName
FROM dbo.Customers
WHERE country LIKE 'USA'
GO
DECLARE @customer_id NVARCHAR(10), @customer_name NVARCHAR(50), @customer_purchase_count INT, @i INT
DECLARE customer_cursor CURSOR FAST_FORWARD FOR
    SELECT CustomerID, CompanyName
FROM dbo.Customers
WHERE country LIKE 'USA'
SET @i = 0
OPEN customer_cursor
FETCH NEXT FROM customer_cursor INTO @customer_id, @customer_name
WHILE @@FETCH_STATUS = 0
BEGIN
    SELECT @customer_purchase_count = COUNT(*)
    FROM dbo.Orders
    WHERE CustomerID LIKE @customer_id
    PRINT @customer_name + ' vásárlások száma: ' + CAST(@customer_purchase_count AS NVARCHAR(5))
    FETCH NEXT FROM customer_cursor INTO @customer_id, @customer_name
END
CLOSE customer_cursor
DEALLOCATE customer_cursor

/*
ÖNÁLLÓ FELADAT #13: A feladat annak kiderítése, hogy a paraméterként kapott ügynök 1) napokban
mérve milyen átlagos gyakorisággal köt nagy értékű rendelést, illetve 2) hányszor fordult elő vele, hogy
két kis értékű rendelése közvetlenül követte egymást. Nagy értékűnek a 200 dollár feletti rendelések
számítanak.
Például tegyük fel, hogy egy ügynök rendeléseinek a dátumai és összegei az alábbiak:
2011. jan. 3. (820 $)
2011. jan. 4. (190 $)
2011. jan. 5. (11,200 $)
2011. jan. 10. (100 $)
2011. jan. 11. (140 $)
2011. jan. 20. (540 $)
Ekkor egyrészt 17 nap alatt 3 nagy értékű rendelése volt, tehát az átlag 5.7 nap, másrészt egyszer fordult
elő vele, hogy egymás után két kis értékű rendelése jött.
24A megoldás javasolt lépései:
1. kurzor készítése az illető ügynök rendelési dátumaira és azok értékére, az előző feladat alapján,
rendezés dátum szerint
2. a kurzor iterálása, a rendelés típusának mentése két rekord között egy változóba
3. tesztelés az Orders táblán
Segítség: SELECT DATEDIFF(day, '2011-02-23', '2011-03-03') -- az eredmény 11, integer
*/
--- - lekerdezes teszt eleje -
GO
DECLARE @emp_id INT = 2
--LastName: Fuller  // parameter
--SELECT o.OrderID,FORMAT(o.OrderDate, 'yyyy-MM-dd') AS OrderDate FROM dbo.Orders AS o 
SELECT o.OrderId, FORMAT(o.OrderDate, 'yyyy-MM-dd') AS OrderDate, SUM(CAST((d.UnitPrice * d.Quantity * (1-d.Discount)) AS DECIMAL(10,2))) AS OrderPrice,
 CASE 
        WHEN SUM(CAST(d.UnitPrice * d.Quantity * (1 - d.Discount) AS DECIMAL(10,2))) > 200 THEN 'N'
        ELSE 'KKKKKKKKK'
    END AS Category
FROM dbo.Orders AS o
    LEFT JOIN [dbo].[Order Details] AS d ON o.OrderId = d.OrderId
    WHERE EmployeeID = @emp_id
    GROUP BY o.OrderId,o.OrderDate
    ORDER BY o.OrderDate
--- - lekerdezes teszt vege -
GO
DECLARE @emp_id INT = 2
--LastName: Fuller  // parameter
DECLARE @order_id INT, @order_date DATE, @order_price FLOAT
DECLARE @count INT = 0, @nagyerteku_count INT = 0, @first_date DATE, @last_date DATE
DECLARE @ez_kiserteku INT = 0, @elozo_kiserteku INT = 0, @egymas_utan_kiserteku_count INT = 0
DECLARE order_cursor CURSOR FAST_FORWARD FOR
    SELECT o.OrderId, FORMAT(o.OrderDate, 'yyyy-MM-dd') AS OrderDate, SUM(CAST((d.UnitPrice * d.Quantity * (1-d.Discount)) AS DECIMAL(10,2))) AS OrderPrice
    FROM dbo.Orders AS o
        LEFT JOIN [dbo].[Order Details] AS d ON o.OrderId = d.OrderId
    WHERE EmployeeID = @emp_id
    GROUP BY o.OrderId,o.OrderDate
    ORDER BY o.OrderDate
OPEN order_cursor
FETCH NEXT FROM order_cursor INTO @order_id, @order_date, @order_price
WHILE @@FETCH_STATUS = 0
BEGIN
    SET @count = @count + 1
    IF @order_price > 200
        BEGIN
            SET @nagyerteku_count = @nagyerteku_count + 1
            SET @ez_kiserteku = 0
        END
    ELSE
        BEGIN
            SET @ez_kiserteku = 1
        END
    IF @ez_kiserteku = 1 AND @elozo_kiserteku = 1
        SET @egymas_utan_kiserteku_count = @egymas_utan_kiserteku_count + 1
    SET @elozo_kiserteku = @ez_kiserteku
    FETCH NEXT FROM order_cursor INTO @order_id, @order_date, @order_price
END
CLOSE order_cursor
DEALLOCATE order_cursor
DECLARE order_cursor CURSOR GLOBAL DYNAMIC SCROLL FOR
    SELECT FORMAT(o.OrderDate, 'yyyy-MM-dd') AS OrderDate
    FROM dbo.Orders AS o
        LEFT JOIN [dbo].[Order Details] AS d ON o.OrderId = d.OrderId
    WHERE EmployeeID = @emp_id
    GROUP BY o.OrderDate
    ORDER BY o.OrderDate
OPEN order_cursor 
    FETCH FIRST FROM order_cursor INTO @first_date
    FETCH LAST FROM order_cursor INTO @last_date
CLOSE order_cursor
DEALLOCATE order_cursor
DECLARE @nr_of_days INT
SELECT @nr_of_days = DATEDIFF(day, @first_date, @last_date)
DECLARE @emp_name NVARCHAR(50)
SELECT @emp_name = LastName FROM dbo.Employees WHERE EmployeeID = @emp_id
PRINT @emp_name + ' összes rendelésszám: '+CAST(@count AS NVARCHAR(4))+' db, ebből nagyértékű rendelés: ' + CAST(@nagyerteku_count AS NVARCHAR(3)) + ' db'
PRINT 'Összes napok száma: ' + CAST(@nr_of_days AS VARCHAR(4)) + ', átlagos nagyértékű üzletkötés ' + CAST(CAST(CAST(@nr_of_days AS DECIMAL(10,2)) / NULLIF(@nagyerteku_count, 0) AS DECIMAL(10,2)) AS NVARCHAR(50)) + ' naponta'
PRINT CAST(@egymas_utan_kiserteku_count AS NVARCHAR(5)) + ' alkalommal fordult elő egymás után két kis értekű rendelés'
